export class Card {

}